import express from 'express';
import ProductManager from 'src/managers/ProductManager.js';

const router = express();
const productManager = new ProductManager();



router.get('/', (req, res) => {
    res.render('index',{});
})

router.get('/realtimeproducts', async (req, res) => {
  const products = await productManager.getAll();
  res.render('realTimeProducts', { products })
});

export default router;